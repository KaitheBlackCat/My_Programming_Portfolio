from matplotlib import animation as animation, pyplot as plt, cm
import numpy as np
import time

x = np.arange(7)
plt.rc("font", family='NanumGothic')

plt.ion()
count = 1

f = open("test.txt", "r")

lines = f.readline()

while lines:
	if not lines:
		break
	strA = "".join(lines)
	strA = strA.strip('\n')
	strA = strA.split(",")
	del strA[0]

	y = list(map(int, strA))
	Avr = sum(y) / len(y)
	plt.yticks([0, 40, 80, 120, 160, 200, 240, 280])
	plt.xticks([0, 1, 2, 3, 4, 5, 6])
	plt.autoscale(False)
	plt.xlim(-1, 7)
	plt.rc("font", family='NanumGothic')
	plt.title(str(count) + "번째 이미지 V값 그래프, 현재 평균 : "+str(int(Avr)))
	plt.bar(x, y)

	plt.show()
	plt.pause(0.001)
	plt.cla()
	lines = f.readline()
	count = count + 1

f.close()